package model;

public class Balsalevy {
	private int id;
	private double tiheys;
	private double korkeus;
	private double leveys;
	private double paino;
	private double pituus;
	private String grain;

	/**
	 * Empty constructor only used by Gson when converting JSON Strings to Java
	 * objects. Set to private to prevent creating uninitialized objects.
	 */
	@SuppressWarnings("unused")
	public Balsalevy() {

	}

	public Balsalevy(int id, double tiheys, double korkeus, double leveys, double paino, double pituus, String grain) {
		this.id = id;
		this.tiheys = tiheys;
		this.korkeus = korkeus;
		this.leveys = leveys;
		this.paino = paino;
		this.pituus = pituus;
		this.grain = grain;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTiheys() {
		return tiheys;
	}

	public void setTiheys(double tiheys) {
		this.tiheys = tiheys;
	}

	public double getKorkeus() {
		return korkeus;
	}

	public void setKorkeus(double korkeus) {
		this.korkeus = korkeus;
	}

	public double getLeveys() {
		return leveys;
	}

	public void setLeveys(double leveys) {
		this.leveys = leveys;
	}

	public double getPaino() {
		return paino;
	}

	public void setPaino(double paino) {
		this.paino = paino;
	}

	public double getPituus() {
		return pituus;
	}

	public void setPituus(double pituus) {
		this.pituus = pituus;
	}

	public String getGrain() {
		return grain;
	}

	public void setGrain(String grain) {
		this.grain = grain;
	}

	@Override
	public boolean equals(Object other) {
		return other instanceof Balsalevy && ((Balsalevy) other).id == this.id;
	}
}
