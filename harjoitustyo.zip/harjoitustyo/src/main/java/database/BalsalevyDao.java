package database;

import java.util.List;

import model.Balsalevy;

public interface BalsalevyDao {

	public List<Balsalevy> getAllMeasurements();

	public Balsalevy getMeasurement(int id);

	public boolean addMeasurement(Balsalevy newMeasurement);

	public boolean removeMeasurement(Balsalevy measurement);

}
