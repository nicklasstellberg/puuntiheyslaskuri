package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Balsalevy;

/**
 * TODO: Complete the implementation of this DAO-class by implementing database
 * operations for each of the CRUD methods.
 */
public class JDBCBalsalevyDao implements BalsalevyDao {

	// TIETOKANNAN YHTEYSLAUSE ELI URL TIETOKANTAAN ON HYVÄ
	// LAITTAA ATTRIBUUTTINA
	private final String URL = "jdbc:sqlite:.\\balsalevy.sqlite";

	@Override
	public List<Balsalevy> getAllMeasurements() {
		// LUO TÄSSÄ ARRAYLIST, JOKA SISÄLTÄÄ BALSALEVY MITTAUKSIA
		List<Balsalevy> mittaukset = new ArrayList<>();

		Connection yhteys = null;
		PreparedStatement lause = null;
		ResultSet haunTulokset = null;

		try {
			// muodostetaan yhteys tietokantaan
			yhteys = DriverManager.getConnection(URL);

			// suoritetaan "SELECT * FROM Balsalevy"
			// TEHDÄÄ TIETOKANTAAN SQL-HAKU, JOKA HAKEE KAIKEN
			String sql = "SELECT * FROM Balsalevy";
			// VALMISTELLAAN SQL LAUSE SUORITTAMISTA VARTEN
			lause = yhteys.prepareStatement(sql);
			// SUORITETAAN SQL LAUSE JA KERÄTÄÄN VASTAUKSET TALTEEN
			haunTulokset = lause.executeQuery();
			// TIETOKANTASISÄLLÖN LÄPIKÄYNTI WHILE LOOPISSA
			// tulostetaan kaikki tuloksena saadut rivit
			while (haunTulokset.next()) {
				// HAUNTULOKSISTA TÄLTÄ RIVILTÄ HAETAAN SARAKKEEN TÄMÄN RIVIN ARVOT
				int id = haunTulokset.getInt("id");
				double tiheys = haunTulokset.getDouble("tiheys");
				double korkeus = haunTulokset.getDouble("korkeus");
				double leveys = haunTulokset.getDouble("leveys");
				double paino = haunTulokset.getDouble("paino");
				double pituus = haunTulokset.getDouble("pituus");
				String grain = haunTulokset.getString("grain");
				// LUODAAN BALSALEVY-MITTAUS OLIO TIETOKANNSTA SAADUILLA ARVOILLA
				Balsalevy mittaus = new Balsalevy(id, tiheys, korkeus, leveys, paino, pituus, grain);
				// JOSSA TALLENNETAAN TIEDOT YKSITELLEN ARRAYLISTIIN
				mittaukset.add(mittaus);
			}

		} catch (SQLException e) {
			System.out.println("Tietokantaan yhdistäminen ei onnistunut.");
			e.printStackTrace();

		} finally {
			// TIETOKANTARESURSSIEN SULKEMINEN OIKEASSA JÄRJESTYKSESSÄ
			if (haunTulokset != null) {
				try {
					haunTulokset.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (lause != null) {
				try {
					lause.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (yhteys != null) {
				try {
					yhteys.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		// LOPUKSI PALAUTETAA LUOTU ARRAYLIST
		return mittaukset;
	}

	@Override
	public Balsalevy getMeasurement(int id) {
		Connection yhteys = null;
		PreparedStatement lause = null;
		ResultSet haunTulokset = null;

		try {
			// muodostetaan yhteys tietokantaan
			yhteys = DriverManager.getConnection(URL);

			// suoritetaan "SELECT * FROM Balsalevy"
			// TEHDÄÄ TIETOKANTAAN SQL-HAKU, JOKA HAKEE KAIKEN
			String sql = "SELECT * FROM Balsalevy";
			// VALMISTELLAAN SQL LAUSE SUORITTAMISTA VARTEN
			lause = yhteys.prepareStatement(sql);
			// SUORITETAAN SQL LAUSE JA KERÄTÄÄN VASTAUKSET TALTEEN
			haunTulokset = lause.executeQuery();
			// TIETOKANTASISÄLLÖN LÄPIKÄYNTI WHILE LOOPISSA
			// tulostetaan kaikki tuloksena saadut rivit
			while (haunTulokset.next()) {
				// HAUNTULOKSISTA TÄLTÄ RIVILTÄ HAETAAN SARAKKEEN TÄMÄN RIVIN ARVOT
				int etsittavaid = haunTulokset.getInt("id");
				double tiheys = haunTulokset.getDouble("tiheys");
				double korkeus = haunTulokset.getDouble("korkeus");
				double leveys = haunTulokset.getDouble("leveys");
				double paino = haunTulokset.getDouble("paino");
				double pituus = haunTulokset.getDouble("pituus");
				String grain = haunTulokset.getString("grain");
				if (etsittavaid == id) {
					Balsalevy mittaus = new Balsalevy(etsittavaid, tiheys, korkeus, leveys, paino, pituus, grain);
					return mittaus;
				}
			}

		} catch (SQLException e) {
			System.out.println("Tietokantaan yhdistäminen ei onnistunut.");
			e.printStackTrace();

		} finally {
			// TIETOKANTARESURSSIEN SULKEMINEN OIKEASSA JÄRJESTYKSESSÄ
			if (haunTulokset != null) {
				try {
					haunTulokset.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (lause != null) {
				try {
					lause.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (yhteys != null) {
				try {
					yhteys.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	@Override
	public boolean addMeasurement(Balsalevy newMeasurement) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet results = null;

		try {
			// muodostetaan yhteys tietokantaan
			connection = DriverManager.getConnection(URL);

			PreparedStatement insertKysely = connection.prepareStatement(
					"INSERT INTO Balsalevy (tiheys, korkeus, leveys, paino, pituus, grain) VALUES (?, ?, ?, ?, ?, ?)");
			insertKysely.setDouble(1, newMeasurement.getTiheys());
			insertKysely.setDouble(2, newMeasurement.getKorkeus());
			insertKysely.setDouble(3, newMeasurement.getLeveys());
			insertKysely.setDouble(4, newMeasurement.getPaino());
			insertKysely.setDouble(5, newMeasurement.getPituus());
			insertKysely.setString(6, newMeasurement.getGrain());

			int rivit = insertKysely.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			if (results != null) {
				try {
					results.close();
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				}
			}
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public boolean removeMeasurement(Balsalevy measurement) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet results = null;

		try {
			// muodostetaan yhteys tietokantaan
			connection = DriverManager.getConnection(URL);

			PreparedStatement insertKysely = connection.prepareStatement("DELETE FROM Balsalevy WHERE (id) = (?)");
			insertKysely.setInt(1, measurement.getId());

			int rivit = insertKysely.executeUpdate();
			if (rivit != 0) {
				System.out.println("Succesfully removed " + measurement.getId());
			} else {
				System.out.println("Could not remove " + measurement.getId());
			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			if (results != null) {
				try {
					results.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

}