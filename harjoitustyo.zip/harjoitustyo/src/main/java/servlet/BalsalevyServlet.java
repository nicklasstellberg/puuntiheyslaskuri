package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.JDBCBalsalevyDao;
import model.Balsalevy;

@WebServlet("/balsalevy")
public class BalsalevyServlet extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {

		JDBCBalsalevyDao dao = new JDBCBalsalevyDao();
		List<Balsalevy> mittaukset = dao.getAllMeasurements();
		req.setAttribute("mittaukset", mittaukset);
		RequestDispatcher disp = req.getRequestDispatcher("WEB-INF/balsalevy.jsp");
		disp.forward(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

		JDBCBalsalevyDao dao = new JDBCBalsalevyDao();

		String stringPaksuus = req.getParameter("thickness").trim().replace(',', '.');
		double paksuus = Double.parseDouble(stringPaksuus);
		String stringPituus = req.getParameter("length").trim().replace(',', '.');
		double pituus = Double.parseDouble(stringPituus);
		String stringLeveys = req.getParameter("width").trim().replace(',', '.');
		double leveys = Double.parseDouble(stringLeveys);
		String stringPaino = req.getParameter("weight").trim().replace(',', '.');
		double paino = Double.parseDouble(stringPaino);
		String grain = req.getParameter("grain").trim();
		double tiheys = (paino * 0.001) / ((pituus * 0.001) * (leveys * 0.001) * (paksuus * 0.001));

		Balsalevy ostos = new Balsalevy(0, tiheys, paksuus, leveys, paino, pituus, grain);
		// tallenna luomasi olio tietokantaan DAO-luokkasi avulla
		dao.addMeasurement(ostos);

		// resp.sendRedirect("/polku/johon/ohjataan");

		resp.sendRedirect("balsalevy");
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		JDBCBalsalevyDao dao = new JDBCBalsalevyDao();
		// selvitä mikä `id` annettiin pyynnön mukana
		String sid = req.getParameter("id");
		int id = Integer.parseInt(sid);
		Balsalevy haettava = dao.getMeasurement(id);
		// poista id:tä vastaava rivi tietokannasta dao-luokan avulla
		dao.removeMeasurement(haettava);
	}
}
