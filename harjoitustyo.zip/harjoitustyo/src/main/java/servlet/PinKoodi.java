package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("")
public class PinKoodi extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		RequestDispatcher disp = req.getRequestDispatcher("WEB-INF/pinkoodi.jsp");
		disp.forward(req, res);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		String syote = req.getParameter("salasana");
		String koodi = "42";

		if (syote.equals(koodi)) {
			resp.sendRedirect("balsalevy");
		} else {
			resp.sendRedirect("pinkoodi");
		}

	}
}
