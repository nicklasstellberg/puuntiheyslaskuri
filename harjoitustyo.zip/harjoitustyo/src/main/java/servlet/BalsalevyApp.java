package servlet;

import java.util.List;
import java.util.Scanner;

import database.BalsalevyDao;
import database.JDBCBalsalevyDao;
import model.Balsalevy;

public class BalsalevyApp {
	private static BalsalevyDao dao = new JDBCBalsalevyDao();

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// LUODAAN BALSALEVYDAO OLIO, JOSTA KUTUSTAAN MYÖHEMMIN METODEITA
		JDBCBalsalevyDao dao = new JDBCBalsalevyDao();

		boolean running = true;

		while (running) {
			System.out.println("Welcome to the shopping list app!\n" + "Available commands:\n" + " list\n"
					+ " add [product name]\n" + " remove [product name]\n" + " help\n" + " find [product id]\n"
					+ " quit");
			System.out.print("> ");
			String command = input.next();
			String nimi = input.nextLine().trim();

			switch (command) {
			case "list":
				// TÄSSÄ KOHDASSA PITÄISI OLLA METODIKUTSU LISTAAMISEEN dao.
				List<Balsalevy> mittaukset = dao.getAllMeasurements();

				for (Balsalevy measurement : mittaukset) {
					System.out.println(measurement.getId() + " " + measurement.getTiheys());
				}
				break;
			case "find":
				// TÄSSÄ KOHDASSA PITÄISI OLLA METODIKUTSU ETSIMISEEN dao.
				int num = Integer.parseInt(nimi);
				Balsalevy haettava = dao.getMeasurement(num);
				System.out.println(haettava.getId() + " " + haettava.getTiheys());
				break;
			case "quit":
				running = false;
				break;
			}
			System.out.println();
		}

		System.out.println("Bye!");
		input.close();
	}

}